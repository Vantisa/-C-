import random
import pygame
from pygame.locals import *
import sys



pygame.init()

WIDTH = 800
HEIGHT = 600

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

window = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Сапёр меню")

background_image = pygame.image.load("background.jpeg")

button_play = pygame.Rect(300, 200, 200, 50)
button_rules = pygame.Rect(300, 300, 200, 50)

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = event.pos

            if button_play.collidepoint(mouse_pos):
                window = pygame.display.set_mode((300, 450))
                pygame.display.set_caption("уровень сложности")

                background_image = pygame.image.load("image.jpeg")

                button_level1 = pygame.Rect(50, 100, 200, 50)
                button_level2 = pygame.Rect(50, 200, 200, 50)
                button_level3 = pygame.Rect(50, 300, 200, 50)

                pygame.draw.rect(window, (255, 255, 255), button_level1)
                pygame.draw.rect(window, (255, 255, 255), button_level2)
                pygame.draw.rect(window, (255, 255, 255), button_level3)

                font = pygame.font.Font(None, 36)
                text_level1 = font.render("легкий", True, (46, 139, 87))
                text_level2 = font.render("средний", True, (240, 230, 140))
                text_level3 = font.render("сложный", True, (220, 20, 60))

                window.blit(background_image, (0, 0))
                window.blit(text_level1, (button_level1.x + 10, button_level1.y + 10))
                window.blit(text_level2, (button_level2.x + 10, button_level2.y + 10))
                window.blit(text_level3, (button_level3.x + 10, button_level3.y + 10))

                pygame.display.update()
                print("переход на игру")

                running = True
                while running:
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            running = False
                        elif event.type == pygame.MOUSEBUTTONDOWN:
                            mouse_pos = event.pos

                            if button_level1.collidepoint(mouse_pos):
                                import pygame
                                import random

                                window_width = 500
                                window_height = 500

                                rows = 10
                                cols = 10

                                num_bombs = 10

                                cell_size = min(window_width // cols, window_height // rows)


                                class cell:
                                    def __init__(self, x, y, width, height, image):
                                        self.x = x
                                        self.y = y
                                        self.width = width
                                        self.height = height
                                        self.bomb = False
                                        self.clicked = False
                                        self.neighbors = 0
                                        self.image = image

                                    def draw(self, screen):
                                        if self.clicked:
                                            pygame.draw.rect(screen, (200, 200, 200),
                                                             (self.x, self.y, self.width, self.height))
                                            if self.bomb:
                                                screen.blit(explosion_img, (self.x, self.y))
                                                if not game_over:
                                                    screen.blit(end_game_img, (0, 0))
                                            elif self.neighbors > 0:
                                                font = pygame.font.Font(None, 30)
                                                text = font.render(str(self.neighbors), True, (0, 0, 0))
                                                text_rect = text.get_rect(
                                                    center=(self.x + self.width // 2, self.y + self.height // 2))
                                                screen.blit(text, text_rect)
                                        else:
                                            screen.blit(self.image, (self.x, self.y))

                                    def contains(self, pos):
                                        return self.x <= pos[0] <= self.x + self.width and self.y <= pos[
                                            1] <= self.y + self.height


                                pygame.init()
                                screen = pygame.display.set_mode((window_width, window_height))
                                pygame.display.set_caption("сапер")

                                explosion_img = pygame.image.load("explosion.jpg")
                                end_game_img = pygame.image.load("end_game.jpeg")
                                congrats_img = pygame.image.load("congrats.jpeg")
                                cell_image = pygame.image.load("gthc.jpeg")
                                flag_image = pygame.image.load("flip.jpeg")

                                grid = []
                                for row in range(rows):
                                    for col in range(cols):
                                        cell_obj = cell(col * cell_size, row * cell_size, cell_size, cell_size,
                                                        cell_image)
                                        grid.append(cell_obj)

                                bomb_cells = random.sample(grid, num_bombs)
                                for cell_obj in bomb_cells:
                                    cell_obj.bomb = True

                                overlay_image = None

                                running = True
                                game_over = False
                                num_flags = num_bombs
                                while running:
                                    screen.fill((0, 0, 0))

                                    for event in pygame.event.get():
                                        if event.type == pygame.QUIT:
                                            running = False
                                        elif event.type == pygame.MOUSEBUTTONDOWN and not game_over:
                                            if event.button == 1:
                                                pos = pygame.mouse.get_pos()
                                                for cell_obj in grid:
                                                    if cell_obj.contains(pos) and not cell_obj.clicked:
                                                        cell_obj.clicked = True
                                                        if cell_obj.bomb:
                                                            game_over = True
                                                        elif cell_obj.neighbors == 0:
                                                            for neighbor in grid:
                                                                if not neighbor.bomb and abs(
                                                                        neighbor.x - cell_obj.x) <= cell_obj.width and abs(
                                                                        neighbor.y - cell_obj.y) <= cell_obj.height:
                                                                    neighbor.clicked = True
                                                                    neighbor.neighbors = sum(
                                                                        1 for n in grid
                                                                        if n.bomb and not n.clicked
                                                                        and abs(
                                                                            n.x - neighbor.x) <= neighbor.width and abs(
                                                                            n.y - neighbor.y) <= neighbor.height
                                                                    )
                                            elif event.button == 3 and num_flags > 0:
                                                pos = pygame.mouse.get_pos()
                                                for cell_obj in grid:
                                                    if cell_obj.contains(pos) and not cell_obj.clicked:
                                                        if not cell_obj.image == cell_image:
                                                            cell_obj.image = cell_image
                                                            num_flags -= 1
                                                        else:
                                                            cell_obj.image = flag_image
                                                            num_flags += 1

                                    if game_over:
                                        overlay_image = end_game_img
                                    elif all(cell_obj.clicked or cell_obj.bomb for cell_obj in grid):
                                        overlay_image = congrats_img
                                        game_over = False

                                    for cell_obj in grid:
                                        cell_obj.draw(screen)

                                    if overlay_image:
                                        screen.blit(overlay_image, (0, 0))

                                    pygame.display.flip()

                                pygame.quit()

                                print("level 1")

                            elif button_level2.collidepoint(mouse_pos):

                                window_width = 700
                                window_height = 700

                                rows = 15
                                cols = 15

                                num_bombs = 60

                                cell_size = min(window_width // cols, window_height // rows)


                                class cell:
                                    def __init__(self, x, y, width, height, image):
                                        self.x = x
                                        self.y = y
                                        self.width = width
                                        self.height = height
                                        self.bomb = False
                                        self.clicked = False
                                        self.neighbors = 0
                                        self.image = image

                                    def draw(self, screen):
                                        if self.clicked:
                                            pygame.draw.rect(screen, (200, 200, 200),
                                                             (self.x, self.y, self.width, self.height))
                                            if self.bomb:
                                                screen.blit(explosion_img, (self.x, self.y))
                                                if not game_over:
                                                    screen.blit(end_game_img, (0, 0))
                                            elif self.neighbors > 0:
                                                font = pygame.font.Font(None, 30)
                                                text = font.render(str(self.neighbors), True, (0, 0, 0))
                                                text_rect = text.get_rect(
                                                    center=(self.x + self.width // 2, self.y + self.height // 2))
                                                screen.blit(text, text_rect)
                                        else:
                                            screen.blit(self.image, (self.x, self.y))

                                    def contains(self, pos):
                                        return self.x <= pos[0] <= self.x + self.width and self.y <= pos[
                                            1] <= self.y + self.height


                                pygame.init()
                                screen = pygame.display.set_mode((window_width, window_height))
                                pygame.display.set_caption("сапер")

                                explosion_img = pygame.image.load("explosion.jpg")
                                end_game_img1 = pygame.image.load("end_game1.jpeg")
                                congrats_img1 = pygame.image.load("congrats1.jpeg")
                                cell_image = pygame.image.load("gthc.jpeg")
                                flag_image = pygame.image.load("flip.jpeg")

                                grid = []
                                for row in range(rows):
                                    for col in range(cols):
                                        cell_obj = cell(col * cell_size, row * cell_size, cell_size, cell_size,
                                                        cell_image)
                                        grid.append(cell_obj)

                                bomb_cells = random.sample(grid, num_bombs)
                                for cell_obj in bomb_cells:
                                    cell_obj.bomb = True

                                overlay_image = None

                                running = True
                                game_over = False
                                num_flags = num_bombs
                                while running:
                                    screen.fill((0, 0, 0))

                                    for event in pygame.event.get():
                                        if event.type == pygame.QUIT:
                                            running = False
                                        elif event.type == pygame.MOUSEBUTTONDOWN and not game_over:
                                            if event.button == 1:
                                                pos = pygame.mouse.get_pos()
                                                for cell_obj in grid:
                                                    if cell_obj.contains(pos) and not cell_obj.clicked:
                                                        cell_obj.clicked = True
                                                        if cell_obj.bomb:
                                                            game_over = True
                                                        elif cell_obj.neighbors == 0:
                                                            for neighbor in grid:
                                                                if not neighbor.bomb and \
                                                                        abs(neighbor.x - cell_obj.x) <= cell_obj.width and \
                                                                        abs(neighbor.y - cell_obj.y) <= cell_obj.height:
                                                                    neighbor.clicked = True
                                                                    neighbor.neighbors = \
                                                                        sum(1 for n in grid
                                                                        if n.bomb and not n.clicked and
                                                                        abs(n.x - neighbor.x) <= neighbor.width and
                                                                        abs(n.y - neighbor.y) <= neighbor.height
                                                                    )
                                            elif event.button == 3 and num_flags > 0:
                                                pos = pygame.mouse.get_pos()
                                                for cell_obj in grid:
                                                    if cell_obj.contains(pos) and not cell_obj.clicked:
                                                        if not cell_obj.image == cell_image:
                                                            cell_obj.image = cell_image
                                                            num_flags -= 1
                                                        else:
                                                            cell_obj.image = flag_image
                                                            num_flags += 1

                                    if game_over:
                                        overlay_image = end_game_img1
                                    elif all(cell_obj.clicked or cell_obj.bomb for cell_obj in grid):
                                        overlay_image = congrats_img1
                                        game_over = False

                                    for cell_obj in grid:
                                        cell_obj.draw(screen)

                                    if overlay_image:
                                        screen.blit(overlay_image, (0, 0))

                                    pygame.display.flip()

                                pygame.quit()

                                print("level 2")

                            elif button_level3.collidepoint(mouse_pos):
                                window_width = 700
                                window_height = 700

                                rows = 25
                                cols = 25

                                num_bombs = 100

                                cell_size = min(window_width // cols, window_height // rows)


                                class cell:
                                    def __init__(self, x, y, width, height, image):
                                        self.x = x
                                        self.y = y
                                        self.width = width
                                        self.height = height
                                        self.bomb = False
                                        self.clicked = False
                                        self.neighbors = 0
                                        self.image = image

                                    def draw(self, screen):
                                        if self.clicked:
                                            pygame.draw.rect(screen, (200, 200, 200),
                                                             (self.x, self.y, self.width, self.height))
                                            if self.bomb:
                                                screen.blit(explosion_img, (self.x, self.y))
                                                if not game_over:
                                                    screen.blit(end_game_img, (0, 0))
                                            elif self.neighbors > 0:
                                                font = pygame.font.Font(None, 30)
                                                text = font.render(str(self.neighbors), True, (0, 0, 0))
                                                text_rect = text.get_rect(
                                                    center=(self.x + self.width // 2, self.y + self.height // 2))
                                                screen.blit(text, text_rect)
                                        else:
                                            screen.blit(self.image, (self.x, self.y))

                                    def contains(self, pos):
                                        return self.x <= pos[0] <= self.x + self.width and self.y <= pos[
                                            1] <= self.y + self.height


                                pygame.init()
                                screen = pygame.display.set_mode((window_width, window_height))
                                pygame.display.set_caption("сапер")

                                explosion_img = pygame.image.load("explosion.jpg")
                                end_game_img1 = pygame.image.load("end_game1.jpeg")
                                congrats_img1 = pygame.image.load("congrats1.jpeg")
                                cell_image = pygame.image.load("gthc.jpeg")
                                flag_image = pygame.image.load("flip.jpeg")

                                grid = []
                                for row in range(rows):
                                    for col in range(cols):
                                        cell_obj = cell(col * cell_size, row * cell_size, cell_size, cell_size,
                                                        cell_image)
                                        grid.append(cell_obj)

                                bomb_cells = random.sample(grid, num_bombs)
                                for cell_obj in bomb_cells:
                                    cell_obj.bomb = True

                                overlay_image = None

                                running = True
                                game_over = False
                                num_flags = num_bombs
                                while running:
                                    screen.fill((0, 0, 0))

                                    for event in pygame.event.get():
                                        if event.type == pygame.QUIT:
                                            running = False
                                        elif event.type == pygame.MOUSEBUTTONDOWN and not game_over:
                                            if event.button == 1:
                                                pos = pygame.mouse.get_pos()
                                                for cell_obj in grid:
                                                    if cell_obj.contains(pos) and not cell_obj.clicked:
                                                        cell_obj.clicked = True
                                                        if cell_obj.bomb:
                                                            game_over = True
                                                        elif cell_obj.neighbors == 0:
                                                            for neighbor in grid:
                                                                if not neighbor.bomb and \
                                                                        abs(neighbor.x - cell_obj.x) <= cell_obj.width and \
                                                                        abs(neighbor.y - cell_obj.y) <= cell_obj.height:
                                                                    neighbor.clicked = True
                                                                    neighbor.neighbors = sum(
                                                                        1 for n in grid
                                                                        if n.bomb and not n.clicked
                                                                        and abs(
                                                                            n.x - neighbor.x) <= neighbor.width and abs(
                                                                            n.y - neighbor.y) <= neighbor.height
                                                                    )
                                            elif event.button == 3 and num_flags > 0:
                                                pos = pygame.mouse.get_pos()
                                                for cell_obj in grid:
                                                    if cell_obj.contains(pos) and not cell_obj.clicked:
                                                        if not cell_obj.image == cell_image:
                                                            cell_obj.image = cell_image
                                                            num_flags -= 1
                                                        else:
                                                            cell_obj.image = flag_image
                                                            num_flags += 1

                                    if game_over:
                                        overlay_image = end_game_img1
                                    elif all(cell_obj.clicked or cell_obj.bomb for cell_obj in grid):
                                        overlay_image = congrats_img1
                                        game_over = False

                                    for cell_obj in grid:
                                        cell_obj.draw(screen)

                                    if overlay_image:
                                        screen.blit(overlay_image, (0, 0))

                                    pygame.display.flip()

                                pygame.quit()
                                print("level 3")

                            window = pygame.display.set_mode((WIDTH, HEIGHT))
                            pygame.display.set_caption("Сапёр меню")


            if button_rules.collidepoint(mouse_pos):
                screen_width = 800
                screen_height = 600

                screen = pygame.display.set_mode((screen_width, screen_height))
                clock = pygame.time.Clock()

                # load the image files
                image_file_path_1 = "назначение.jpeg"
                image_file_path_2 = "правила.jpeg"

                image_1 = pygame.image.load(image_file_path_1)
                image_2 = pygame.image.load(image_file_path_2)

                image_rect_1 = image_1.get_rect(center=screen.get_rect().center)
                image_rect_2 = image_2.get_rect(center=screen.get_rect().center)

                page_number = 1
                total_pages = 2

                rule = True
                while rule:
                    for event in pygame.event.get():
                        if event.type == QUIT:
                            rule = False
                            # pygame.quit()
                            # sys.exit()
                        elif event.type == KEYDOWN:
                            if event.key == K_RIGHT:
                                page_number = (page_number + 1) % (total_pages + 1)
                                if page_number == 0:
                                    page_number = 1

                    mouse_pos = pygame.mouse.get_pos()

                    button_rect = pygame.Rect(10, 10, 100, 50)

                    if button_rect.collidepoint(mouse_pos):
                        pygame.draw.rect(screen, (200, 200, 200), button_rect)
                        if pygame.mouse.get_pressed()[0]:
                            page_number = (page_number + 1) % (total_pages + 1)
                    else:
                        pygame.draw.rect(screen, (255, 255, 255), button_rect)

                    font = pygame.font.Font(None, 28)
                    text = font.render("next page", True, (0, 0, 0))
                    text_rect = text.get_rect(center=button_rect.center)
                    screen.blit(text, text_rect)

                    screen.fill((255, 255, 255))
                    if page_number == 1:
                        screen.blit(image_1, image_rect_1.topleft)
                    elif page_number == 2:
                        screen.blit(image_2, image_rect_2.topleft)

                    pygame.display.update()
                    clock.tick(60)



        background_image = pygame.image.load("background.jpeg")
        window.blit(background_image, (0,0))

        pygame.draw.rect(window, WHITE, button_play)
        pygame.draw.rect(window, WHITE, button_rules)

        pygame.font.init()
        font = pygame.font.Font(None, 36)
        text_play = font.render("Играть", True, BLACK)
        text_rules = font.render("Правила", True, BLACK)
        window.blit(text_play, (350, 210))
        window.blit(text_rules, (345, 310))

        pygame.display.update()